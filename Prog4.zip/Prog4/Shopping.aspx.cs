﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog4.Prog4
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        private const double tax = 0.055;
        private const int COL_1 = 0;
        private const int COL_2 = 1;
        private const int COL_3 = 2;
        private const int COL_4 = 3;

        private double subtotal
        {
            get
            {
                if (Session["subtotal"] == null)
                {
                    Session["subtotal"] = 0;
                }
                return (double)Session["subtotal"];
            }
            set { Session["subtotal"] = value; }
        }

        private double grandTotal
        {
            get
            {
                if (Session["grandTotal"] != null)
                {
                    return (double)Session["grandTotal"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["grandTotal"] = value; }
        }

        private double taxTotal
        {
            get
            {
                if (Session["taxTotal"] != null)
                {
                    return (double)Session["taxTotal"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["taxTotal"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (!IsPostBack)
            {
                //prodTable = SQLDataClass.GetTable();
            }
        }

        protected void btnCompute_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < App_Code.SQLDataClass.tblProduct.Rows.Count; i++)
                {
                    TableRow row = new TableRow();
                    TableCell cell = new TableCell();
                    if (App_Code.SQLDataClass.tblProduct.Rows[i][COL_1].ToString() == txtID.Text &&
                        App_Code.SQLDataClass.tblProduct.Rows[i][COL_2].ToString() == txtName.Text)
                    {
                        txtPrice.Text = App_Code.SQLDataClass.tblProduct.Rows[i][COL_3].ToString();
                    }
                }
                txtID.ReadOnly = true;
                txtName.ReadOnly = true;
                txtQuantity.ReadOnly = true;
                subtotal = double.Parse(txtPrice.Text) * double.Parse(txtQuantity.Text);
                txtSubTotal.Text = subtotal.ToString();
                taxTotal = subtotal * tax;
                txtTax.Text = taxTotal.ToString();
                grandTotal = subtotal + taxTotal;
                txtGrandTotal.Text = grandTotal.ToString();
                txtPrice.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtSubTotal.Text));
                txtSubTotal.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtSubTotal.Text));
                txtTax.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtTax.Text));
                txtGrandTotal.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtGrandTotal.Text));
                btnReset.Focus();

            }
            catch (Exception ex)
            {
                Response.Write("Error: " + ex.Message);
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtID.ReadOnly = false;
            txtName.ReadOnly = false;
            txtQuantity.ReadOnly = false;
            txtID.Text = "";
            txtName.Text = "";
            txtPrice.Text = "";
            txtQuantity.Text = "";
            txtSubTotal.Text = "";
            txtTax.Text = "";
            txtGrandTotal.Text = "";
            txtID.Focus();
        }
    }
}