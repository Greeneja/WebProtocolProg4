﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace prog4.Prog4.App_Code
{
    public class SQLDataClass
    {
        private static SqlDataAdapter prodAdapter;
        private static SqlCommand prodCmd = new SqlCommand();
        private static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
        public static DataTable tblProduct = new DataTable("Product");

        public static void setupProdAdapter
()
        {
            //con.ConnectionString = ConStr;
            prodCmd.Connection = con;
            prodCmd.CommandType = CommandType.Text;
            prodCmd.CommandText = "Select * from Product order by ProductID";
            prodAdapter = new SqlDataAdapter(prodCmd);
            prodAdapter.FillSchema(tblProduct, SchemaType.Source);
        }

        public static void getAllProducts()
        {
            if (prodAdapter == null)
            {
                setupProdAdapter();
            }
            prodCmd.CommandText = "Select * from Product order by ProductID";
            try
            {
                if (!(tblProduct == null))
                {
                    tblProduct.Clear();
                }
                prodAdapter.Fill(tblProduct);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                con.Close();
            }
        }

        public static void UpdateProduct(string theID, string newName, double newPrice, string newDesc)
        {
            prodCmd.CommandText = "Update Product " +
            "Set ProductName = '" + newName + "', " +
            "UnitPrice = " + newPrice + ", " +
            "Description = '" + newDesc + "' " +
            "Where ProductID = '" + theID + "'";
            try
            {
                con.Open();
                prodCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public static void DeleteProduct(string theID)
        {
            prodCmd.CommandText = "Delete From Product " +
                "Where ProductID ='" + theID + "'";
            try
            {
                con.Open();
                prodCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public static void AddProduct(string theID, string Name, double Price, string Desc)
        {
            //prodCmd.CommandText = "Insert Into Product(ProductID, ProductName, UnitPrice, Description) " +
            //    "Values(‘" + theID + "’, ‘" + Name + "’, " + Price + ", ‘" + Desc + "’)";
            prodCmd.CommandText = "insert into Product(ProductID, ProductName, UnitPrice, Description)" +
                    " values (@pID, @pName, @pPrice, @pDesc)";
            prodCmd.Parameters.AddWithValue("@pID", theID);
            prodCmd.Parameters.AddWithValue("@pName", Name);
            prodCmd.Parameters.AddWithValue("@pPrice", Price);
            prodCmd.Parameters.AddWithValue("@pDesc", Desc);
            try
            {
                con.Open();
                prodCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}